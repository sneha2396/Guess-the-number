'use strict';

let number=Math.trunc(Math.random()*20)+1;
document.
let score=20;

document.querySelector('.check').addEventListener('click',function(){
 const guess=Number(document.querySelector('input').value);

 if(!guess){
  document.querySelector('.start').textContent='Enter a number!'
 }else if(guess===number){
 document.querySelector('.start').textContent='You won!!'
 document.querySelector('body').style.backgroundColor='red'
 }else if(guess>number){
  if(score>1){document.querySelector('.start').textContent='Number is too high'
 score--;
    document.querySelector(".two").textContent = score;}
  else if()
  
 }else if(guess<number){
  document.querySelector(".start").textContent = "Number is too low"
 }
})