'use strict';

let number=Math.trunc(Math.random()*20)+1;
// document.querySelector('.question').textContent=number;
let score=20;
let highscore=0;

document.querySelector('.check').addEventListener('click',function(){
  const guess=Number(document.querySelector('input').value);
  // console.log(guess,typeof guess);

  if(!guess){
  document.querySelector('.start').textContent='No number!'
  }
  else if(guess===number){
  document.querySelector('.start').textContent='you won!'
  document.querySelector('body').style.backgroundColor='orange'
  if (score>highscore){
    highscore=score;
    document.querySelector('.zero').textContent=highscore
  }
  }
  else if(guess>number){
  if (score>1){
    document.querySelector(".start").textContent = "Number is too high!";
    score--;
    document.querySelector(".two").textContent = score;
  }else{
    document.querySelector(".start").textContent = "you lost the game";
  }
  }
  else if(guess<number){
  if(score>1){
  document.querySelector(".start").textContent = "Number is too low!"
  score--;
  document.querySelector(".two").textContent = score;
  }else{
    document.querySelector(".start").textContent = "you lost the game!";
  }
  }
});

document.querySelector('.again').addEventListener('click',function(){
  score=20;
  number = Math.trunc(Math.random() * 20) + 1;
  document.querySelector(".question").textContent = number;
  document.querySelector(".start").textContent = "Start Guessing...";
  document.querySelector('.two').textContent=score;
  document.querySelector('.question').textContent='?';
  document.querySelector("input").value='';
  document.querySelector("body").style.backgroundColor = rgb(126, 248, 70);
})
